<html>
<body>
<p> Database Connection Nurse </p>


<?php 

require 'db.php';
session_start();

$username = $_GET['username']; 
$password = $_GET['password']; 
$result = $mysqli->query("' SELECT username , pw, role  FROM user_tab WHERE username = '$username' and pw = '$userid'");


 
?>
 </body>
</html>