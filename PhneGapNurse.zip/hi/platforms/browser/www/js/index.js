    /*    document.addEventListener('deviceready', onDeviceReady, false);

		function on deviceready(){
			console.log('Device Ready....!')
		}
		
  
		con.connect(function(err) {
		if (err) throw err;
		/*Select all customers with the address "Park Lane 38":
		con.query(" SELECT username , pw  FROM user_tab WHERE username = userid and pw = userid ", function (err, result) {
			if (err) throw err;
				console.log(result);
			});
			$('#output').html("Username: " + window.localStorage.getItem("username") + "<br>" + 
                                    "Email: " + window.localStorage["email"]
                                );
		});
		
		
		
		//authenticate user with PHP & MySQL using phonegap.

		if(isset($_POST['login']))
		{
			$email=mysql_real_escape_string(htmlspecialchars(trim($_POST['email'])));
			$password=mysql_real_escape_string(htmlspecialchars(trim($_POST['password'])));
			$login=mysql_num_rows(mysql_query("select * from `phonegap_login` where `email`='$email' and `password`='$password'"));
			if($login!=0)
			{
				echo "success";
			}
			else
			{
				echo "failed";
			}
		}
			*/
			
			function submitForm() {
                 
                /*var userid = $('[user="username"]').value();
                var pw = $('[user="password"]').value();
                 
                window.localStorage.setItem("username", userid);
                window.localStorage.setItem('password', pw);
                 
               $.mobile.changePage( "#page2", { reverse: false, transition: "slide" } );
                 
                */
				
				alert("Falsch");
                     
                return false;
            }
			
 
		