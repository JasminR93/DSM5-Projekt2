<?php

<?php
$y = $_POST["y"];

/* Hier wird das Mail mit der Variable $y verschickt. */

echo $y; 
?>

?>